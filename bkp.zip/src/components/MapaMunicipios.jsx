import { MapContainer, TileLayer, CircleMarker, Popup } from "react-leaflet";
import { municipios } from "../data/municipios";

function corRisco(score) {
  if (score <= 25) return "#4caf50";
  if (score <= 50) return "#ffeb3b";
  if (score <= 75) return "#ff9800";
  return "#f44336";
}

export default function MapaMunicipios({
 onSelect
}) {

 return (

  <MapContainer
    center={[-5.2,-39.5]}
    zoom={7}
    style={{
      height:"500px"
    }}
  >

   <TileLayer
    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
   />

   {municipios.map(municipio => (
    <CircleMarker
      key={municipio.id}
      center={[municipio.lat, municipio.lng]}
      radius={14}
      pathOptions={{
        color: corRisco(municipio.scoreFinal),
        fillColor: corRisco(municipio.scoreFinal),
        fillOpacity: 0.85,
      }}
      eventHandlers={{ click: () => onSelect(municipio) }}
    >
      <Popup>{municipio.nome} — Score: {municipio.scoreFinal}</Popup>
    </CircleMarker>
   ))}

  </MapContainer>

 );

}