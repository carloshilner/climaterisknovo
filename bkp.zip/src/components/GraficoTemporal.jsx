import {
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from "recharts";
import { Typography } from "@mui/material";
import CustomTooltip from "./CustomTooltip";
import { dadosTemporais } from "../data/municipios";

export default function GraficoTemporal({

 municipio

}) {

 if (!municipio) return null;

  const dados = dadosTemporais[municipio.nome] ?? [];

  return (
    <>
      <Typography variant="h6" sx={{ mb: 1 }}>
        Evolução Temporal — {municipio.nome}
      </Typography>

  <ResponsiveContainer
   width="100%"
   height={400}
  >

   <LineChart data={dados}>

    <CartesianGrid
      strokeDasharray="4 4"
    />

    <XAxis
      dataKey="mes"
    />

    <YAxis
      domain={[0,100]}
    />

    <Tooltip
      content={<CustomTooltip/>}
    />

    <Legend/>

    <Line
      dataKey="scoreGeral"
      stroke="#2e7d32"
      strokeWidth={4}
      name="Score Geral"
    />

    <Line
      dataKey="seca"
      stroke="#f44336"
      strokeWidth={3}
      name="Seca"
    />

    <Line
      dataKey="incendio"
      stroke="#ff9800"
      strokeWidth={3}
      name="Incêndio"
    />

    <Line
      dataKey="enchente"
      stroke="#2196f3"
      strokeWidth={3}
      name="Enchente"
    />

   </LineChart>

  </ResponsiveContainer>
    </>
  );
}