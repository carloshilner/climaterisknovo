export const municipios = [
  {
    id: 1,
    nome: "Sobral",
    lat: -3.688,
    lng: -40.348,
    populacao: 210711,
    area: 2122,
    scoreFinal: 60,
    scoreSeca: 82,
    scoreIncendio: 68,
    scoreEnchente: 31,
  },
  {
    id: 2,
    nome: "Crato",
    lat: -7.234,
    lng: -39.409,
    populacao: 131050,
    area: 1176,
    scoreFinal: 48,
    scoreSeca: 55,
    scoreIncendio: 42,
    scoreEnchente: 47,
  },
];

export const dadosTemporais = {
  Sobral: [
    { mes: "Jan", seca: 70, incendio: 30, enchente: 20, scoreGeral: 40 },
    { mes: "Fev", seca: 75, incendio: 40, enchente: 25, scoreGeral: 46 },
    { mes: "Mar", seca: 82, incendio: 55, enchente: 31, scoreGeral: 56 },
  ],
  Crato: [
    { mes: "Jan", seca: 50, incendio: 25, enchente: 40, scoreGeral: 38 },
    { mes: "Fev", seca: 55, incendio: 30, enchente: 45, scoreGeral: 43 },
    { mes: "Mar", seca: 60, incendio: 38, enchente: 50, scoreGeral: 49 },
  ],
};
